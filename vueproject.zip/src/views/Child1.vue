<template>
  <div class="about">
    <h1>This is an Child1 page</h1>
  </div>
</template>
