<template>
  <div >
    <h1>This is Student page</h1>
    <el-table
      :data="list"
      style="width: 100%;text-align:center;">
      
      <el-table-column
        prop="name"
        label="姓名"
        width="180">
      </el-table-column>

      <el-table-column
        prop="age"
        label="年龄"
        width="180">
      </el-table-column>
      
    </el-table>
    
    <el-button type="primary" @click="add">新增记录</el-button>
    <el-button type="primary" @click="update">修改list最后一个记录</el-button>
    <el-button type="primary" @click="del">删除list最后一个记录</el-button>

    

     <Edit :defaultFormData="item" :visible="visible" :title="title" v-if="visible" @close="close" @updateList='updateList' @addList='addList'></Edit>
  </div>
  

</template>
<script>
  import Edit from "./module/edit";
export default {
  name: 'Student',
  components:{Edit},
  data(){
    return{
      title:'',
      visible:false,
      item:{},
      list: [
        {
          name:'001',
          age:1
        },
        {
          name:'002',
          age:2
        },
        {
          name:'003',
          age:3
        }
      ]
    }
  },
  mounted(){
    
    
  },
  methods:{
    del(){
      this.list.splice(this.list.length-1,1)
    },
    addList(item){
      this.list.push(item)
      this.visible = false
      
    },
    updateList(item){
      this.list.splice(this.list.length-1,1,item)
      this.visible = false
      
    },
    close(){
        this.visible = false
    },
    add(){
      this.title = '新增'
      this.visible = true
      this.item = {}
    },
    update(){
      //console.log(this.list.length)
      this.title = '修改'
      this.visible = true
      this.item = this.list[this.list.length-1]
      //console.log(this.item)


    }
  }
}
</script>