<template>
  <div >
    <h1>This is Basic2 page</h1>
    <button v-on:click="incresCount()">点击一下，count+1</button>
    <span>{{count}}</span>
    <br/>

    <input type="text" v-model="textChange" @keyup="inputChange" @keydown="downChange"/>
    <span>{{textChange}}</span>
    <br/>
  <!-- <div @mouseenter="enter" @mouseleave="leave">
      测试快
  </div> 

  <div >
    <div @click="show" style="border:solid 1px red;">
        <button @click="show">A</button>
        <button @click.stop="show">B</button>
    </div>
  </div>-->

  <div @click="show1" style="border:solid 1px yellow;">
    <button @click="show1">A</button>
    <div @click.capture="show2" style="border:solid 1px red;">
        
        <button @click.once="show3">B</button>
    </div>
  </div>

 <!--过滤器-->
  <span>--{{msg | reverse}}--</span>
  <br/>
  <span>--{{msg | add(' xmut')}}--</span>
  <br/>
  <span>--{{msg | uppercase}}--</span>
  <br/>
<!--watch-->
  <button @click="init">初始化海贼团成员</button> 
  <br/>
  <button @click="change">修改海贼团名字</button> 
  <br/>
<!--computed-->
  <input type="text" v-model="price" />
  <br/>
  <input type="number" v-model="number" />
  <br/>
  {{total}}

  </div>
  
  
</template>
<script>
export default {
  name: 'Basic2',
  data(){
    return{
      count:1,
      textChange:'',
      msg:' hello world ',
      hzt:'草帽海贼团',
      sl:'suolong',
      nm:'namei',

      price:1,
      number:1
    }
  },
  filters:{
    reverse:function (value){
      if(!value) return ''
      value = value.toString()

      //split变成数组，reverse把数组逆序，join把逆序后的数组组合成字符串，trim去除前后空格
      return value.split('').reverse().join('').trim()
    },
    add:function(val,val2){
      if(!val) return ''
      if(!val2) return val

      return val.toString()+val2.toString()
    }
  },
  watch:{
    hzt:function (value){
      this.sl = value+'=>'+'suolong';
      this.nm = value+'=>' + 'nami';
      console.log(this.sl)
      console.log(this.nm)
    }
  },
  computed:{
    total:function(){
      return this.price*this.number
    }
  },
  methods:{
    change(){
      this.hzt = '橡胶海贼团'
      console.log(this.hzt)
      //this.init()
      // console.log(this.sl)
      // console.log(this.nm)
    },
    init(){
        this.sl = this.hzt +'=>'+'suolong'
        this.nm = this.hzt +'=>'+ 'nami'
        console.log(this.sl)
        console.log(this.nm)
    },
    show(){
      console.log('show')
    },
    show1(){
      console.log('1')
    },
    show2(){
      console.log('2')
    },
    show3(){
      console.log('3')
    },
    incresCount(){
      this.count = this.count+1
    },
    downChange(){
      console.log('downChange')  
    },
    inputChange(){
      console.log('change')      
    },
    enter(){
      console.log('enter')
    },
    leave(){
      console.log('leave')
    }
  }
}
</script>
<style scoped>

</style>