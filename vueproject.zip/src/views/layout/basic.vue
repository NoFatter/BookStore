<template>
  <BasicsLayout></BasicsLayout>
</template>

<script>
  import BasicsLayout from './basic/BasicsLayout'
  export default {
    components:{BasicsLayout}
  }
</script>

<style scoped>

</style>
