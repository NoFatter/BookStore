<template>
  <div >
    <h1>This is vue lifecycle page</h1>
    <div id="myDiv">{{msg}}</div>

    <button @click="changeMSG()">点击修改msg的值</button>
  </div>
  
</template>
<script>
export default {
  name: 'Life',
  data(){
    return{
      msg : 'hello',
      timer : null
    }
  },
  beforeCreate(){
    //生命周期第一个钩子,data和methods中的数据和方法还没有初始化
    //console.log(this.msg)  //undefined 
    //this.show()  //show is not a function
  },
  created(){
    //生命周期第二个钩子,data和methods中的数据和方法已经初始化
    // console.log(this.msg) 
    // this.show()  
  },
  beforeMount(){
    //生命周期第三个钩子，此时还没有完成页面渲染，整个页面其实都是字符串，因此不存在dom节点
    //console.log(document.getElementById('myDiv'))  //null
  },
  mounted(){
    //生命周期第四个钩子，此时页面已经渲染完毕，有dom节点
    //console.log(document.getElementById('myDiv').innerText)

    this.timer = setInterval(() => {
      this.msg = 'world'
      console.log(this.msg)
    }, 1000) 
  },
  beforeUpdate(){
    //生命周期第五个钩子，只有data发生变化时才会触发。此时data中的数据还没有同步更新到dom节点
    // console.log(this.msg)  //xmut
    // console.log(document.getElementById('myDiv').innerText) //hello

  },
  updated(){
      //生命周期第六个钩子，只有data发生变化时才会触发。此时data中的数据已经同步更新到dom节点
    //   console.log(this.msg)  //xmut
    // console.log(document.getElementById('myDiv').innerText) //xmut
  },
  beforeDestroy(){
    //生命周期第七个钩子，只有在页面被销毁时触发，此时整个vue对象还可以使用
    // console.log('beforeDestroy') //hello
    // this.show()
  },
  destroyed(){
     clearInterval(this.timer)
     //生命周期第八个钩子，只有在页面被销毁时触发，此时整个vue对象已被销毁
      // console.log('destroyed') //hello
      // console.log(this.msg)
  },
  methods:{
   show(){
     console.log('show')
   },
   changeMSG(){
     this.msg = 'xmut'
   }
  },
}
</script>
<style scoped>

</style>