<template>
  <div >
    <h1>This is MyLoginUI page</h1>
    
  <el-form :model="formData" status-icon :rules="rules" ref="formData" label-width="100px" class="demo-ruleForm">
    <el-form-item label="用户名" prop="username">
      <el-input type="text" v-model="formData.username"></el-input>
    </el-form-item>
    <el-form-item label="密码" prop="password">
      <el-input type="password" v-model="formData.password" autocomplete="off"></el-input>
    </el-form-item>
    <!-- <el-form-item label="电话号码" prop="phone">
      <el-input type="text" v-model="formData.phone" autocomplete="off"></el-input>
    </el-form-item> -->
   
  
    <el-form-item>
      <el-button type="primary" @click="submit()">提交</el-button>
      <!-- <el-button @click="resetForm('formData')">重置</el-button> -->
    </el-form-item>
  </el-form>
     
   <el-button type="primary" @click="clear()">清空localstorage</el-button>
  </div>
</template>
<script>
import util from "@/libs/util"
import {login,register} from "@/api/modules/user"
import {setStore,getStore,removeStore} from "@/libs/storage"
import {setCookie} from "@/libs/cookie"
export default {
  name: 'MyLoginUI',
  data(){
    var validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入密码'));
        } else if(value.length <6){
          
          callback(new Error('密码长度不能小于6'));
        }
      };
    //  var validataPhone = (rule, value, callback) => {
    //    let reg = /^[1][3,4,5,7,8][0-9]{9}$/;
    //   if (!reg.test(value)) {
    //     callback(new Error("手机号格式错误"));
    //   } else {
    //     callback();
    //   }
    //  }
    return{
        formData:{
          username:'',
          password:'',
         // phone:''
        },
        rules:{
             username: [
                { required: true,message: '请填写用户名', trigger: 'blur' },
                { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
                
              ],
            password: [
                { required: true,message: '请填写密码', trigger: 'blur' },
                { validator: validatePass, trigger: 'blur' }
              ]
            //   ,
            // phone: [
            //     { required: true,message: '请填写电话号码', trigger: 'blur' },
            //     { validator: validataPhone, trigger: 'blur' }
            //   ]
        }
    }
  },
  
  methods:{
   clear(){
    removeStore("token")
   },

   submit(){

     
     
      login({
       ...this.formData
      }).then(res => {
        //res = Result
        
        setCookie("user",JSON.stringify(res.data.user))
        let token = res.data.token
        setStore("token",token)

        util.initRouter(this)
        //console.log(getStore("token"))
      }).catch(err =>{
        this.toast(err,2)
      })
   }
  }
}
</script>
<style >

</style>