<template>
  <div class="about">
    <h1>This is an MyMixin page</h1>
   {{GL.projectName}}
   <br/>
   <button @click="test">点击测试</button>
   <br/>

   {{this.schoolName}}
   <br/>
   {{this.sayHi()}}
   <br/>

   <button @click="myMessage">测试elementui的message</button>
  </div>
</template>
<script>
export default {
  name: 'MyMixin',
  data(){
    return{
      
    }
  },
 
  methods:{
      test(){
        this.GL.hello()
      },
      myMessage(){
        this.toast('ok success',3)
      }
  },
}
</script>
<style >

</style>