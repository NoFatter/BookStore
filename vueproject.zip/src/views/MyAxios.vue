<template>
  <div >
    <h1>This is MyAxios page</h1>
    <button @click="sendGet()">点击发送get请求</button>
    <br/>
    <button @click="sendPost()">点击发送post请求</button>
    <br/>
    <button @click="sendPostJson()">点击发送postJson请求</button>
  </div>
  
</template>
<script>
import axios from 'axios'
import qs from 'qs'
export default {
  name: 'MyAxios',
  data(){
    return{
      
    }
  },
  mounted(){
    axios.defaults.baseURL = "/api";
  },
  methods:{
    sendPostJson(){
      axios.post(
        'test/postJson',
        {name:'xmut',age:40})
      .then(function(res){
        console.log(res.data)
      }).catch(function(err){
        console.log(err)
      })
    },
    sendPost(){
       axios.post('test/postTest',qs.stringify({id:'xmut2021'}),{headers: {'Content-Type': 'application/x-www-form-urlencoded'}}).then(function(res){
        console.log(res.data)
      }).catch(function(err){
        console.log(err)
      })
    //   var data = {id:'xmut2021'}
    //   axios.post('test/postTest',qs.stringify(data), 
    // {headers: {'Content-Type': 'application/x-www-form-urlencoded'}}).then(function(res){
    //     console.log(res.data)
    //   }).catch(function(err){
    //     console.log(err)
    //   })
    },
    sendGet(){
      axios.get('test/get')
      .then(function(res){
        //handle success
        //res.data = Result
        //console.log(res.data)
        let data = res.data

        switch(data.statusCode){
          case '200':
            console.log('操作成功')
            break;
          case '400':
            console.log('操作失败')
            break;
          case '401':
            console.log('未授权')
            break;
          case '500':
            console.log('服务器内部错误')
            break;
          default:
            console.log('success')
            break;
        }
        
      })
      .catch(function(err){
        //handle error
        console.log('myError:'+err)
      })
    }
  }
}
</script>
<style scoped>

</style>