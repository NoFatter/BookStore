<template>
  <div class="about">
    <h1>This is an Child2 page</h1>
  </div>
</template>
