<template>
  <div >
    <h1>This is Basic page</h1>
    <input type="text" v-model.lazy="inputMSG">
    <span>{{inputMSG}}</span>
    <br/>

    <input type="number" v-model="inputNumber">
    <span>{{inputNumber}}</span>
    <br/>

    <input type="text" v-model.trim="msg">
    <span>your msg is :-{{msg}}-end</span>
    <br/>

    <button v-on:click="change()">点击修改inputMSG</button>
    <br/>

    <input type="checkbox" id='vue' value="vue" v-model="checkMSG"/>
    <label for="vue">Vue</label>
    <input type="checkbox" id='springboot' value="springboot" v-model="checkMSG"/>
    <label for="springboot">Springboot</label>
    <input type="checkbox" id='jsp' value="jsp" v-model="checkMSG"/>
    <label for="jsp">Jsp</label>
    <br/>
    <span>{{checkMSG}}</span>
    <br/>

    <input type="radio" id='movie' value="movie" name="radioName" v-model="radioMSG"/>
    <label for="movie">movie</label>
    <input type="radio" id='sing' value="sing" name="radioName" v-model="radioMSG"/>
    <label for="sing">sing</label>
    
    <br/>
    <span>{{radioMSG}}</span>
    <br/>

    <select v-model="selectMSG" multiple>
        <option value="width">width</option>
        <option value="height">height</option>
        <option value="color">color</option>
    </select>
    <span>{{selectMSG}}</span>
    <br/>

    <div v-bind:class="{'divBind':flag}">
      test v-bind
    </div>
    <img v-bind:src="src" v-bind:alt="alt"/>
    <br/>
    <img src="@/assets/images/logo.png" v-bind:alt="alt" v-bind:title="obj"/>
    <br/>
    <img src="@/assets/images/logo.png"  :title="myMethod()"/>
    <br/>

    <ul>
      <li v-for="myary in forAry" :key="myary.id">
        {{myary.id}}----{{myary.name}}

      </li>
    </ul>
  </div>
  
</template>
<script>
export default {
  name: 'Basic',
  data(){
    return{
      forAry:[
        {id:'1',
          name:'xmut',
          age:18},
        {id:'2',
          name:'xmu',
          age:100}
      ],
      obj:{
          id:1,
          name:'xmut',
          age:18,
          toString(){
              return 'id-'+this.id+":name-"+this.name+":age-"+this.age
          }
      },
      ary:['movie','sing','song'],
      title:'this is title',
      alt:'this is alt',
      src:'assets/images/logo.png',
      flag:true,
      msg:'',
      inputNumber:123,//Number
      inputMSG:'default',//String
      checkMSG:[],//Array
      radioMSG:'',
      selectMSG:[]
    }
  },
  methods:{
    change(){
      this.inputMSG = 'hello world'
    },
    myMethod(){
      return "hello xmut"
    }
  }
}
</script>
<style scoped>
.divBind{
  color: red;
}
</style>