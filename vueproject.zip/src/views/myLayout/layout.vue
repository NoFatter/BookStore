<template>
 <el-container>
  <el-header>Header</el-header>
  <el-container>
    <el-aside width="200px" > <Sidebar></Sidebar></el-aside>
    <el-main><router-view/></el-main>
  </el-container>
</el-container>
</template>

<script>

  import Sidebar from './Sidebar.vue'
  export default {
      name:'myLayout',
      components: { Sidebar},
  }
</script>

<style scoped>
.el-header, .el-footer {
    background-color: #B3C0D1;
    color: #333;
    text-align: center;
    line-height: 60px;
  }
  
  .el-aside {
    background-color: #D3DCE6;
    color: #333;
    text-align: center;
    height: 600px;
  }
  
  .el-main {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
    line-height: 160px;
  }
  
  body > .el-container {
    margin-bottom: 40px;
  }
  
  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }
  
  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }
</style>