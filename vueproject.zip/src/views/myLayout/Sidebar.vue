<template>
   <div>
    <!-- <div class="menu-toggle" @click.prevent="bindCollapseChange">
      <i class="basics icon-outdent" v-show="!isCollapse" title="收起"></i>
      <i class="basics icon-indent" v-show="isCollapse" title="展开"></i>
    </div> -->
    <el-menu
      class="el-menu-vertical"
      background-color="#D3DCE6"
      text-color="#FFFFFF"
      :collapse="isCollapse"
      :unique-opened="true"
      
      >
      <el-submenu index="1">
        <template slot="title"><i class="el-icon-message"></i>首页</template>
       
          <el-menu-item index="1-1" @click="_navigate('/')">home</el-menu-item>
        
      </el-submenu>

      <el-submenu index="2">
        <template slot="title"><i class="el-icon-message"></i>example</template>
       
          <el-menu-item index="1-1" @click="_navigate('/myBook')">书籍管理</el-menu-item>
        
      </el-submenu>
       
<el-submenu index="3">
        <template slot="title"><i class="el-icon-message"></i>基础信息管理</template>
       
          <el-menu-item index="1-1" @click="_navigate('/myDic')">字典类型管理</el-menu-item>
        
      </el-submenu>
    <el-submenu index="4">
        <template slot="title"><i class="el-icon-message"></i>用户角色菜单管理</template>
       
          <el-menu-item index="1-1" @click="_navigate('/myUser')">用户管理</el-menu-item>
           <el-menu-item index="1-1" @click="_navigate('/myRole')">角色管理</el-menu-item>
          <el-menu-item index="1-1" @click="_navigate('/myMenu')">菜单管理</el-menu-item>
        
      </el-submenu>  
      

    </el-menu>
   </div>
</template>
<script>
  import '@/assets/styles/basics-icon.css'
  import util from  '@/libs/util'

  export default {
    data() {
      return {
       isCollapse: false
      }
    },
    computed: {
     
    },
    mounted() {
      
    },
    methods: {
      bindCollapseChange() {
        this.isCollapse = !this.isCollapse;
      },
      _navigate(name) {
       // this.$store.commit('SET_DEFAULT_MENU_ACTIVE', index)
        this.navigate(name)
      },
     
    }
  }
</script>

<style scoped>
  .aside{
    background: #001529;
    overflow-y: scroll;
  }

  i {
    font-size: 16px !important; /*no*/
    color: #FFFFFF;
  }

  .iconfont {
    vertical-align: middle;
    margin-right: 5px; /*no*/
    width: 24px; /*no*/
    text-align: center;
  }

  .menu-toggle i {
    font-size: 16px !important; /*no*/
  }

  .submenu {
    font-weight: bold;
  }

  .child-title {
    padding-left: 12px; /*no*/
  }
</style>
