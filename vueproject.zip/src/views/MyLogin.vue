<template>
  <div >
    <h1>This is MyLogin page</h1>
    
      用户名：<input type="text" v-model="formData.username"/><br/>
      密码：<input type="text"  v-model="formData.password"/><br/>
      <button @click="submit()">提交</button>
  <br/>
      用户名：<input type="text" v-model="formData.username"/><br/>
      密码：<input type="text"  v-model="formData.password"/><br/>
      <button @click="register()">提交</button>
   
  </div>
</template>
<script>
import {login,register} from "@/api/modules/user"
export default {
  name: 'MyLogin',
  data(){
    return{
        formData:{
          username:'',
          password:''
        }
    }
  },
  
  methods:{
    register(){
        register({
       ...this.formData
      }).then(res => {
        this.toast(res.message)
      }).catch(err =>{
        this.toast(err,2)
      })
    },

   submit(){
     
      login({
       ...this.formData
      }).then(res => {
        this.toast(res.message)
        console.log(res.data)
      }).catch(err =>{
        this.toast(err,2)
      })
   }
  }
}
</script>
<style >

</style>