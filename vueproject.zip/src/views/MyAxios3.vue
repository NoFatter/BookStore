<template>
  <div >
    <h1>This is MyAxios3 page</h1>
   
    <button @click="send2s()"> 点击发送请求-2s后触发</button>
    <br/>
<button @click="linkExecute()"> 点击发送链式请求触发</button>
<br/>

 <el-form :model="formData"  label-width="130px">
      <el-form-item label="名字" prop="name">
        <el-input v-model="formData.name"></el-input>
      </el-form-item>
      <el-form-item label="年龄" prop="age">
        <el-input v-model="formData.age"></el-input>
      </el-form-item>
     
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="sendPostJson"
                >{{'确认提交'}}</el-button>
    </span>

  </div>
  
</template>
<script>
import {myGet,myPost,myPostJson} from '@/api/hello/hello'
export default {
  name: 'MyAxios3',
  data(){
    return{
      formData:{
        name:'',
        age:0
      }
    }
  },
  mounted(){
    
  },
  methods:{
    sendPostJson(){
     
      myPostJson({
        ...this.formData
      }).then(function(res){
         console.log('success:'+res.message)
      }).catch(function(err){
         console.log('error:'+err)
      })

    },
    linkExecute(){
        this.myPromise()
        .then(data =>{
          console.log(data)
         return this.sayHello()
        })
        .catch(err =>{
          console.log(err)
          return Promise.reject(err)
        })
        .then(data =>{
          console.log(data)
          return 'end'
        })
        .catch(err =>{
          console.log(err)
          return Promise.reject(err)
        })
        .then(data =>{
          console.log(data)
        })
        .catch(err =>{
          console.log(err)
        })
    },
     myPromise(){
        var p = new Promise(function(resolve, reject){
            //做一些异步操作
            setTimeout(function(){
                console.log('execute first');
                //resolve('执行下一个回调1');
                reject('error execute')
            }, 2000);
        });
        return p;            
    },
    sayHello(){
       var p = new Promise(function(resolve, reject){
            //做一些异步操作
            setTimeout(function(){
                console.log('second ');
                resolve('执行下一个回调2');
                //reject('error execute')
            }, 2000);
        });
        return p;     
    },

    send2s(){
     
      this.runAsync(function(data){
             console.log(data)
         })
     },

     runAsync(callback){
         setTimeout(function(){
            console.log('finish1')
            callback('anything1')
         },2000)
     }
  }
}
</script>
<style scoped>

</style>