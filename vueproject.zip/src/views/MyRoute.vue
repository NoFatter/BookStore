<template>
  <div >
    <h1>This is vue myRoute page</h1>
    query:{{$route.query.name}}--{{$route.query.age}}<br/>
    params:{{$route.params.test}}
    <hr/>
    <router-link to="/about">点击跳转到about</router-link>
    <hr/>
    <button @click="toAbout()">点击跳转到about</button>
    <hr/>
    <button @click="replaceAbout()">替换当前页面about</button>
     <hr/>
    <button @click="back()">返回上一个页面</button>
    <hr/>
    <button @click="goMyself()">带参数跳转到自己</button>
    <hr/>

    <!--点击按钮1，下方展示某个页面；点击按钮2，下方展示另一个页面-->
    <router-link to="/child1">展示1</router-link> |
    <router-link to="/child2">展示2</router-link> 
    <router-view/>
<hr/>
    <button @click="toBadidu()">跳转到baidu</button>
    <br/>
    <a href="https://www.baidu.com" target="_blank">to Baidu</a>
    
    <!-- <button @click="show(1)">展示1</button>
    <button @click="show(2)">展示2</button>

    <div id="div1">


    </div>

    <div id="div2">


    </div> -->
  </div>
  
</template>
<script>
export default {
  name: 'MyRoute',
  data(){
    return{
      msg:'hello world'
    }
  },
  beforeRouteEnter (to, from, next) {
    // 整个Router实例还没有初始化完毕
    //console.log(this.msg)
    next()
  },
  beforeRouteUpdate(to, from, next){
    console.log(this.msg)
    next()
  },
  beforeRouteLeave (to, from, next) {
     console.log('leave')
    next()
  },
  mounted(){
    //console.log(this.$route)
  },
  methods:{
    toBadidu(){
        window.location.href='https://www.baidu.com'
    },
    toAbout(){
      //默认通过path进行页面的跳转
      //this.$router.push('/about')
      //通过name进行页面跳转
      this.$router.push({
        name:'About'
      })
    },
    replaceAbout(){
       //替换当前浏览页面
      this.$router.replace('/about')
    },
    back(){
      this.$router.go(-1)
    },
    goMyself(){
        this.$router.push({
          name:'MyRoute',
          query:{//get请求里头的参数
            name:'xmut',
            age:40
          },
          params:{//post表单里头的参数
            test:'19soft2'
          }
        })
    }
  },
}
</script>
<style scoped>

</style>