<template>
  <div >
    <h1>This is MyAxios2 page</h1>
    <button @click="sendGet()">点击发送get请求</button>
    <br/>
    <button @click="sendPost()">点击发送post请求</button>
    <br/>

     <el-form :model="formData"  label-width="130px">
      <el-form-item label="名字" prop="name">
        <el-input v-model="formData.name"></el-input>
      </el-form-item>
      <el-form-item label="年龄" prop="age">
        <el-input v-model="formData.age"></el-input>
      </el-form-item>
     
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="sendPostJson"
                >{{'确认提交'}}</el-button>
    </span>

  </div>
  
</template>
<script>
import {myGet,myPost,myPostJson} from '@/api/hello/hello'
export default {
  name: 'MyAxios2',
  data(){
    return{
      formData:{
        name:'',
        age:0
      }
    }
  },
  mounted(){
    
  },
  methods:{
    sendPostJson(){
     
      myPostJson({
        ...this.formData
      }
        ).then(function(res){
         console.log(res.data)
      }).catch(function(err){
         console.log(err)
      })
    },
    sendPost(){
       myPost({id:'xmut1234'}).then(function(res){
         console.log(res.data)
      }).catch(function(err){
         console.log(err)
      })
    },
    sendGet(){
      
      myGet().then(function(res){
         console.log(res.data)
      }).catch(function(err){
         console.log(err)
      })
    }
  }
}
</script>
<style scoped>

</style>