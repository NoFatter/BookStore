<template>
  <div >
    <h1>This is vue MyComponent page</h1>

    <Sub1 :msg=msg :age=age :obj=obj :ary=ary @rollback='fRollback'></Sub1>
    {{msg}}--{{age}}
    <hr>

    <Sub2 v-model="modelMsg"></Sub2>
    father:{{modelMsg}}
  </div>
  
</template>
<script>
import Sub1 from '@/components/sub1.vue'
import Sub2 from '@/components/sub2.vue'
export default {
  name: 'MyComponent',
  components:{Sub1,Sub2},
  data(){
    return{
      msg:'hello',
      age:120,
      obj:{
        id:1,
        name:'xmut'
      },
      ary:['xmu','fzu'],
      modelMsg:'google'
    }
  },
  methods:{
    fRollback(val,val2){
      this.msg = val
      this.age = val2
    }
  }
}
</script>
<style scoped>

</style>