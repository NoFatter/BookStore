<template>
  <div class="about">
    <h1>This is an MyDirective page</h1>
    name:<input type="text"  v-fo/>
    <br/>
    password:<input type="text" />
    <br/>
    <div class="myDrag" v-drag>拖拽效果测试</div>
  </div>
</template>
<script>
import myd from '@/plugins/myDirective'
export default {
  name: 'MyDirective',
  data(){
    return{
      
    }
  },
  directives:{//局部指令
    fo:{
      inserted: function (el) {
        myd.myFocus(el)
      }
    },
    drag:{
      inserted:function(el){
          myd.myDrag(el)
      }
    }
  },
  mounted(){
    //document.getElementById("name").focus()
  },
  methods:{
    
  },
}
</script>
<style >
.myDrag{
  position: absolute;
  widows: 600px;
  height: 100px;
  background: red;
}
</style>