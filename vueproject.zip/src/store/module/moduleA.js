export default {
    //必须的
    namespaced: true,
    state:{
        count: 2
    },
    getters:{
       
    },
    mutations: {
       
    }

};