const projectName = 'my first vue project'

//function hello(){

//}
const hello = ()=>{
    console.log('hello world')
}


export default{
    projectName,
    hello
}