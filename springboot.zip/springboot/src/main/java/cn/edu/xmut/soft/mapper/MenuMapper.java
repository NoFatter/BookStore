package cn.edu.xmut.soft.mapper;

import cn.edu.xmut.soft.entity.Menu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 菜单表 Mapper 接口 chrimer
 * </p>
 *
 * @author chrimer
 * @since 2021-11-09
 */
public interface MenuMapper extends BaseMapper<Menu> {

}
