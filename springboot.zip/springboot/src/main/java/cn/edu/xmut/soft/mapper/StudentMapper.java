package cn.edu.xmut.soft.mapper;

import cn.edu.xmut.soft.entity.Student;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 学生表 Mapper 接口 chrimer
 * </p>
 *
 * @author chrimer
 * @since 2021-10-26
 */
public interface StudentMapper extends BaseMapper<Student> {

}
