package cn.edu.xmut.soft.mapper;

import cn.edu.xmut.soft.entity.Dic;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 字典表 Mapper 接口 chrimer
 * </p>
 *
 * @author chrimer
 * @since 2021-11-09
 */
public interface DicMapper extends BaseMapper<Dic> {

}
