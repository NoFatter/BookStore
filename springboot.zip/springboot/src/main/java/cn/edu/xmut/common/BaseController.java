package cn.edu.xmut.common;

import org.springframework.transaction.annotation.Transactional;

/**
 * 基础Controller
 * @author bill
 *
 */
@Transactional
public class BaseController {

}
