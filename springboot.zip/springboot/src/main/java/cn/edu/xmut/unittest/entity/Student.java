package cn.edu.xmut.unittest.entity;

import lombok.Data;

/**
 * @ClassName Student
 * @Description: TODO
 * @Author linjiangyi
 * @Date 2021-10-26
 * @Version V1.0
 **/
@Data
public class Student {
    private String name;
    private String no;
    private Integer age;
    private Double height;
    private boolean blFlag;


}
