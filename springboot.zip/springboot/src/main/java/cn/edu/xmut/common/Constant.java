package cn.edu.xmut.common;

/**
 * @ClassName Constant
 * @Description: TODO
 * @Author linjiangyi
 * @Date 2021-11-09
 * @Version V1.0
 **/
public class Constant {
    public static final int GL_USEFUL = 1;
    public static final int GL_UNUSEFUL = 0;
}
